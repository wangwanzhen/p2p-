import News from '../components/News'
import Media from '../components/Media'
import Details from '../components/Details'
export default [
	{
		path: '/',
		name: '',
		component: News
	},{
		path: '/news',
		name: 'news',
		component: News
	},{
		path: '/media',
		name: 'media',
		component: Media
	},{
		path: '/details/:id',
		name: 'details',
		component: Details
	}
]