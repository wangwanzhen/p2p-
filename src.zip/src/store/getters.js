export default {
	isLoading (state) {
		return state.loading
	},
	isHead (state) {
		return state.head
	}

}