export default {
	showLoading(state){
		state.loading = true
	},
	hideLoading(state){
		state.loading = false
	},
	showHead(state){
		state.head = true
	},
	hideHead(state){
		state.head = false
	}
}