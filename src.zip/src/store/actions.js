export default {
	showLoading:({commit})=>{
		commit('showLoading')
	},
	hideLoading:({commit})=>{
		commit('hideLoading')
	},
	showHead:({commit})=>{
		commit('showHead')
	},
	hideHead:({commit})=>{
		commit('hideHead')
	}
}