<template>
	<div id="nav"></div>
</template>

<script>
export default {
	name:'navBar'
}
</script>