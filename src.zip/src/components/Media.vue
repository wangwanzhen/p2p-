<template>
  <div class="home">
    <!-- <BannerView></BannerView> -->
    <MediaList></MediaList>
    <FooterView></FooterView>
  </div>
</template>

<script>
import MediaList from './ListM.vue'
import FooterView from './Nav.vue'


export default {
  name: 'meida',
  data () {
    return {
    }
  },
  components: {
    MediaList,
    FooterView
  }
}
</script>

<!-- Add "scoped" attribute to limit CSS to this component only -->
<style scoped lang="scss">
@import '../style/mixin';
.home{
    margin-top: 1.8rem;
}
</style>
