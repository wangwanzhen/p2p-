// window.URLS = 'http://test.xizhifq.com';//打包上线时
window.URLS = '/api';//开发环境